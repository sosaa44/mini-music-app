import streamlit as st
import pandas as pd
from sqlalchemy import text

# Datenbankverbindung
conn = st.connection("postgresql", type="sql")

st.title("Mini Music App – von Aisosa")

# Tabs erstellen
tab1, tab2, tab3 = st.tabs(["Songs & Artists", "Song & Artist hinzufügen", "Playlists"])

# Tab 1: Anzeigen
with tab1:
    st.header("Alle Songs")
    songs = conn.query("SELECT * FROM songs ORDER BY song_id;", ttl=0)
    st.dataframe(songs)

    st.header("Alle Artists")
    artists = conn.query("SELECT * FROM artists ORDER BY name;", ttl=0)
    st.dataframe(artists)

# Tab 2: Hinzufügen
with tab2:
    # Artist hinzufügen
    st.header("Artist hinzufügen")
    with st.form("artist_form"):
        artist_name = st.text_input("Artist Name")
        artist_land = st.text_input("Land")
        artist_genre = st.text_input("Genre")
        add_artist = st.form_submit_button("Hinzufügen")
        
        if add_artist and artist_name:
            with conn.session as s:
                s.execute(
                    text("INSERT INTO artists (name, land, genre) VALUES (:name, :land, :genre)"),
                    {"name": artist_name, "land": artist_land, "genre": artist_genre}
                )
                s.commit()
            st.success("Artist hinzugefügt!")
            st.rerun()

    # Song hinzufügen
    st.header("Neuen Song hinzufügen")
    artists_list = conn.query("SELECT artist_id, name FROM artists ORDER BY name;", ttl=0)
    
    with st.form("song_form"):
        song_titel = st.text_input("Song Titel")
        selected_artist = st.selectbox(
            "Artist",
            options=artists_list["artist_id"],
            format_func=lambda x: artists_list[artists_list["artist_id"]==x]["name"].values[0]
        )
        song_dauer = st.number_input("Dauer (Sekunden)", min_value=1, value=180)
        song_year = st.number_input("Jahr", min_value=1900, max_value=2025, value=2023)
        add_song = st.form_submit_button("Hinzufügen")

        if add_song and song_titel:
            with conn.session as s:
                s.execute(
                    text("INSERT INTO songs (titel, dauer_sekunden, release_year, artist_id) VALUES (:titel, :dauer, :year, :artist_id)"),
                    {"titel": song_titel, "dauer": song_dauer, "year": song_year, "artist_id": selected_artist}
                )
                s.commit()
            st.success("Song hinzugefügt!")
            st.rerun()

# Tab 3: Playlists
with tab3:
    col1, col2 = st.columns(2)

    # Playlist erstellen
    with col1:
        st.subheader("Neue Playlist")
        with st.form("playlist_form"):
            p_name = st.text_input("Name")
            p_ersteller = st.text_input("Erstellt von", value="Aisosa")
            create_playlist = st.form_submit_button("Erstellen")
            
            if create_playlist and p_name:
                with conn.session as s:
                    s.execute(
                        text("INSERT INTO playlists (name, erstellt_von) VALUES (:name, :erstellt_von)"),
                        {"name": p_name, "erstellt_von": p_ersteller}
                    )
                    s.commit()
                st.success("Playlist erstellt!")
                st.rerun()

    # Song zu Playlist
    with col2:
        st.subheader("Song hinzufügen")
        playlists = conn.query("SELECT playlist_id, name FROM playlists;", ttl=0)
        songs_for_playlist = conn.query("SELECT song_id, titel FROM songs;", ttl=0)

        with st.form("add_song_to_playlist"):
            selected_playlist = st.selectbox(
                "Playlist",
                options=playlists["playlist_id"],
                format_func=lambda x: playlists[playlists["playlist_id"]==x]["name"].values[0]
            )
            selected_song = st.selectbox(
                "Song",
                options=songs_for_playlist["song_id"],
                format_func=lambda x: songs_for_playlist[songs_for_playlist["song_id"]==x]["titel"].values[0]
            )
            pos = st.number_input("Position", min_value=1, value=1)
            add_to_playlist = st.form_submit_button("Hinzufügen")

            if add_to_playlist:
                with conn.session as s:
                    s.execute(
                        text("INSERT INTO playlist_songs (playlist_id, song_id, position) VALUES (:p_id, :s_id, :pos)"),
                        {"p_id": selected_playlist, "s_id": selected_song, "pos": pos}
                    )
                    s.commit()
                st.success("Hinzugefügt!")
                st.rerun()

    # Playlists anzeigen
    st.subheader("Meine Playlists")
    playlist_data = conn.query("""
        SELECT p.name AS playlist_name, p.erstellt_von, s.titel, a.name AS artist, ps.position
        FROM playlists p
        LEFT JOIN playlist_songs ps ON p.playlist_id = ps.playlist_id
        LEFT JOIN songs s ON ps.song_id = s.song_id
        LEFT JOIN artists a ON s.artist_id = a.artist_id
        ORDER BY p.name, ps.position
    """, ttl=0)

    if len(playlist_data) == 0:
        st.info("Keine Playlists vorhanden")
    else:
        for p_name in playlist_data["playlist_name"].unique():
            p_songs = playlist_data[playlist_data["playlist_name"] == p_name]
            ersteller = p_songs["erstellt_von"].values[0]
            with st.expander(f"{p_name} (von {ersteller})"):
                st.dataframe(p_songs[["titel", "artist", "position"]])
