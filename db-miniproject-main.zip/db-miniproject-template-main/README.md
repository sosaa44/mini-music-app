# Mini Music App

- Aisosa Omokaro

## Projektidee

Die Mini Music App ist eine Webanwendung zur Verwaltung von Musik-Playlists. Benutzer können Artists und Songs zur Datenbank hinzufügen, neue Playlists erstellen und Songs zu diesen Playlists hinzufügen. Die App zeigt alle Songs, Artists und Playlists übersichtlich an und ermöglicht es, Playlists mit ihren enthaltenen Songs und Artists zu durchsuchen. Das Projekt nutzt eine PostgreSQL-Datenbank und Streamlit als Frontend.

## ER Modell

### Entitätstypen:
1. artists – Musikkünstler (Name, Land, Genre)
2. songs – Musikstücke (Titel, Dauer, Erscheinungsjahr)
3. playlists – Wiedergabelisten (Name, Ersteller, Erstellungsdatum)

### Beziehungstypen:
1. artists -> songs (1:n) – Ein Artist kann mehrere Songs haben, ein Song gehört zu einem Artist
2. playlists -> songs (n:m) – Eine Playlist kann mehrere Songs enthalten, ein Song kann in mehreren Playlists sein. Diese Beziehung wird durch die Tabelle `playlist_songs` umgesetzt.

### Kardinalitäten:
- Artist zu Song: 1:n (ein Artist, viele Songs)
- Playlist zu Song: n:m (viele Playlists, viele Songs)

[ER-Design Mini Projekt](er-design.png "ER-Design Mini Projekt")

## Beschreibung der Streamlit-App

### 1. Eingabeformular (was wird erfasst?)

Die App bietet mehrere Formulare zur Dateneingabe:

- Artist hinzufügen: Name, Land, Genre des Künstlers
- Song hinzufügen: Titel, Artist (Dropdown), Dauer in Sekunden, Erscheinungsjahr
- Playlist erstellen: Playlist-Name, Ersteller
- Song zu Playlist hinzufügen: Auswahl einer Playlist (Dropdown), Auswahl eines Songs (Dropdown), Position in der Playlist

### 2. Datenanzeige (welche Abfrage wird angezeigt?)

Die App zeigt folgende Daten an:

- Tab 1 – Songs & Artists:
  - Alle Songs mit ID, Titel, Dauer, Jahr und Artist-ID
  - Alle Artists mit ID, Name, Land und Genre

- Tab 3 – Playlists:
  - Alle Playlists mit ihren Songs (JOIN über `playlists`, `playlist_songs`, `songs` und `artists`)
  - Anzeige in erweiterbaren Boxen mit Song-Titel, Artist-Name und Position
  - Filter: Gruppierung nach Playlist-Name

Die Hauptabfrage nutzt LEFT JOINs um Playlists auch anzuzeigen, wenn sie noch keine Songs enthalten:


## Ausführen der App


1. `pip install -r requirements.txt`
2. `python setup_db.py`
3. `python -m streamlit run streamlit_app.py`