-- Artists
INSERT INTO artists (name, land, genre) VALUES
('Taylor Swift', 'USA', 'Pop'),
('Ed Sheeran', 'UK', 'Pop'),
('Adele', 'UK', 'Soul'),
('Drake', 'Canada', 'Hip-Hop'),
('Billie Eilish', 'USA', 'Alternative'),
('Coldplay', 'UK', 'Rock'),
('Beyonce', 'USA', 'R&B'),
('The Weeknd', 'Canada', 'R&B'),
('Imagine Dragons', 'USA', 'Rock'),
('Rihanna', 'Barbados', 'Pop');

-- Songs
INSERT INTO songs (titel, dauer_sekunden, release_year, artist_id) VALUES
('Shake it off', 230, 2008, 1),
('Shape of You', 240, 2017, 2),
('Hello', 295, 2015, 3),
('God''s Plan', 198, 2018, 4),
('Bad Guy', 194, 2019, 5),
('Viva la Vida', 242, 2008, 6),
('Halo', 261, 2008, 7),
('Blinding Lights', 200, 2019, 8),
('Believer', 204, 2017, 9),
('Diamonds', 220, 2012, 10);

-- Playlists
INSERT INTO playlists (name, erstellt_von) VALUES
('Chill Vibes', 'Aisosa'),
('Workout', 'Tim'),
('Party Hits', 'Lena'),
('Roadtrip', 'Aisosa'),
('Study Time', 'Tim'),
('Love Songs', 'Lena'),
('Morning Boost', 'Sara'),
('Evening Relax', 'Luka'),
('Top 40', 'Lena'),
('Throwback', 'Aisosa');

-- Playlist-Songs (Beziehungen)
INSERT INTO playlist_songs (playlist_id, song_id, position) VALUES
(1, 1, 1),
(1, 5, 2),
(2, 2, 1),
(2, 4, 2),
(3, 3, 1),
(3, 7, 2),
(4, 9, 1),
(4, 10, 2),
(5, 6, 1);
