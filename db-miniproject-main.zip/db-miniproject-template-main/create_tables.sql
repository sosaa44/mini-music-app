-- Tabelle 1: Artists
CREATE TABLE artists (
    artist_id SERIAL PRIMARY KEY,           
    name VARCHAR(200) NOT NULL,      
    land VARCHAR(100),                      
    genre VARCHAR(100)                      
);

-- Tabelle 2: Songs
CREATE TABLE songs (
    song_id SERIAL PRIMARY KEY,
    titel VARCHAR(200) NOT NULL,
    dauer_sekunden INT CHECK (dauer_sekunden > 0),
    release_year INT CHECK (release_year >= 1800),
    artist_id INT NOT NULL,
    CONSTRAINT unique_song_per_artist UNIQUE (artist_id, titel),
    FOREIGN KEY (artist_id) REFERENCES artists(artist_id) ON DELETE CASCADE
);


-- Tabelle 3: Playlists
CREATE TABLE playlists (
    playlist_id SERIAL PRIMARY KEY,        
    name VARCHAR(200) NOT NULL,            
    erstellt_von VARCHAR(100),              
    created_date DATE DEFAULT CURRENT_DATE  
);

-- Tabelle 4: Playlist-Songs (Beziehungstabelle)
CREATE TABLE playlist_songs (
    playlist_id INT NOT NULL,
    song_id INT NOT NULL,
    position INT,                          
    PRIMARY KEY (playlist_id, song_id),
    FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id) ON DELETE CASCADE,
    FOREIGN KEY (song_id) REFERENCES songs(song_id) ON DELETE CASCADE
);

